#!/bin/bash

/usr/bin/python3 /usr/bin/zipx/ntp_face/Change_Camera_Time.py

